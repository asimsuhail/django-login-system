from django.shortcuts import render, redirect
from django.http import HttpResponse
#from . import views
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
# Create your views here.


def home(request):
    return render(request, "authenticationn/index.html")


def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        fname    = request.POST['fname']
        lname    = request.POST['lname']
        email    = request.POST['email']
        password = request.POST['password']
        cpassword= request.POST['cpassword']

        myuser            = User.objects.create_user(username, email, password)
        myuser.first_name = fname
        myuser.last_name  = lname

        myuser.save()
        messages.success(request, "your account has been creaetd successfully")

        return redirect('signin')
    return render(request, "authenticationn/signup.html")


def signin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate( username=username, password=password)

        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request, 'authenticationn/index.html', { 'fname' : fname})
        else:
            messages.error(request, "invalid credentials")
            return redirect('home')
    return render(request, "authenticationn/signin.html")


def signout(request):
    logout(request)
    messages.success(request, "logged out successfully!")
    return redirect('home')
